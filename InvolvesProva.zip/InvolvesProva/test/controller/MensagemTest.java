package controller;

import org.junit.Test;

public class MensagemTest {
    
    @Test
    public void imprimirErro() {
        Mensagem.imprimirErro("erro");
    }
}
