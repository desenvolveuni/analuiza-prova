package controller;

public class Mensagem {
	
	public static void imprimirErro(String mensagem){
		System.out.println(mensagem);
	}
	
}
